<?php
$file = fopen("test.txt","a");
if( 0 == strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') )
{
    //Make sure that the content type of the POST request has been set to application/json
    $contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
    if(strcasecmp($contentType, 'application/json') != 0){
        fwrite($file,date('y-m-d')."\nrequest is not json");
    }

    //Receive the RAW post data.
    $content = trim(file_get_contents("php://input"));

    //Attempt to decode the incoming RAW post data from JSON.
    $decoded = json_decode($content, true);

    //If json_decode failed, the JSON is invalid.
    if(!is_array($decoded)){
        fwrite($file,date('y-m-d')."\nreceived content contained invalid json");
    }
    $decoded['added_key'] = 'post_test';
}
else
{   // GET
    $decoded = array();
    foreach ( $_GET as $k => $v )
    {
        $decoded[$k] = $v;
    }
    $decoded['added_key'] = 'get_test';
}
fwrite($file,date('y-m-d')."\ncontent=".print_r($decoded,true));
fclose($file);

/* Echo back the json encoded reply */
header('Content-Type: application/json');
echo json_encode($decoded);